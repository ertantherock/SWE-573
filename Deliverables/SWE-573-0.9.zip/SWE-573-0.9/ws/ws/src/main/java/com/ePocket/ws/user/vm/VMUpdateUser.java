package com.ePocket.ws.user.vm;

import lombok.Data;

@Data
public class VMUpdateUser {
	private String username;
	private String image;
	

}
