<h1>Hello Everyone</h1>
<h2>This is a SWE 573 Class Repo</h2>
<p>In this repository you can check wiki page to see about how to use git? Wikidata and etc.</p>
<p>Every week this repo will be updated according to <b>class requirement.</b></p>
<p>In the first week requirements: I have created new wiki page, created new issue and customized issue tags.</p>

# <p>Newest Update 15.12.2022: </p>
### Application hasbeen builded with frontend and backend side. .Jar file has been created and this .Jar file dockerized.
### After dockerization, I have pushed this docker file to Docker HUB.
### After Pushing, I have deployed this  application on Azure platform. Also I have created Azure SQL Database and my database now online.
### You can check my deployed application on https://epocketdeployed.salmonisland-c42dc852.canadacentral.azurecontainerapps.io/#/ 

# <p> V2 of Application </p>

<p>1.Signup and Login Pages not changed. Just added control mechanizms such as is user name used before for sign up? Is username or password secure enaugh etc.</p>
<p>2.List of Users added to application. When user logged in, he/she can see them on All Users pane on the topbar.</p>

![image](https://user-images.githubusercontent.com/107481123/207957567-6db1bebb-daf9-4842-83ed-d3ebbcd2c6e9.png)

<p>3.When user loged in, they can see their profiles when clicking on topbar @username.</p>

![image](https://user-images.githubusercontent.com/107481123/207957989-4ddae7d6-52ce-45c9-845e-fc717c60eb35.png)

<p>4.When users at the homepage. They can share posts on the left and they can see posts on the right. When clicking on share posts, context area is getting bigger and share and cancel buttons shown up. Links are clickable and buttonized.</p>

![image](https://user-images.githubusercontent.com/107481123/207958193-e5ab8308-4d8b-450a-810f-6600de8e7bfd.png)

<p>V1 of Application</p>

Sign Up Page with React:

![image](https://user-images.githubusercontent.com/107481123/200592941-09b9ea44-3e6c-42bd-b9a3-2cc77eb612ed.png)

Database Connection:

![image](https://user-images.githubusercontent.com/107481123/200592390-e2949937-c465-4337-bd78-76d6197519c7.png)

Java Spring Boot for Sign Up:

![image](https://user-images.githubusercontent.com/107481123/200592710-c125ba82-a171-410a-bf9f-6aaddbf138d7.png)
