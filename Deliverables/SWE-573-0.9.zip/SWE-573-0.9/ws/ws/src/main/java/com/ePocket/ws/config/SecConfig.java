package com.ePocket.ws.config;

public class SecConfig {

}
